<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row">
      <div class="col-md-8 col-md-offset-4">
         <div class="panel panel-default">
            <div class="panel-heading">Register</div>
            <div class="panel-body">
               <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                  <?php echo e(csrf_field()); ?>

                  <div class="form-group<?php echo e($errors->has('first') ? ' has-error' : ''); ?>">
                     <label for="first" class="col-md-4 control-label">First</label>
                     <div class="col-md-6">
                        <input id="first" type="text" class="form-control" name="first" value="<?php echo e(old('first')); ?>" required autofocus>
                        <?php if($errors->has('first')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('first')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>

                  <div class="form-group<?php echo e($errors->has('last') ? ' has-error' : ''); ?>">
                     <label for="last" class="col-md-4 control-label">Last</label>
                     <div class="col-md-6">
                        <input id="last" type="text" class="form-control" name="last" value="<?php echo e(old('last')); ?>" required autofocus>
                        <?php if($errors->has('last')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('last')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>


                  <div class="form-group<?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
                     <label for="address" class="col-md-4 control-label">Address</label>
                     <div class="col-md-6">
                        <input id="address" type="text" class="form-control" name="address" value="<?php echo e(old('address')); ?>" required>
                        <?php if($errors->has('address')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('address')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>


                  <div class="form-group<?php echo e($errors->has('city') ? ' has-error' : ''); ?>">
                     <label for="city" class="col-md-4 control-label">City</label>
                     <div class="col-md-6">
                        <input id="city" type="text" class="form-control" name="city" value="<?php echo e(old('city')); ?>" required>
                        <?php if($errors->has('city')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('city')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>


                  <div class="form-group<?php echo e($errors->has('state') ? ' has-error' : ''); ?>">
                     <label for="state" class="col-md-4 control-label">State</label>
                     <div class="col-md-6">
                        <input id="state" type="text" class="form-control" name="state" value="<?php echo e(old('state')); ?>" required>
                        <?php if($errors->has('state')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('state')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>


                  <div class="form-group<?php echo e($errors->has('phonenumber') ? ' has-error' : ''); ?>">
                     <label for="phonenumber" class="col-md-4 control-label">Phone Number</label>
                     <div class="col-md-6">
                        <input id="phonenumber" type="text" class="form-control" name="phonenumber" value="<?php echo e(old('phonenumber')); ?>" required>
                        <?php if($errors->has('phonenumber')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('phonenumber')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>

                  <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                     <label for="email" class="col-md-4 control-label">E-Mail Address</label>
                     <div class="col-md-6">
                        <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required>
                        <?php if($errors->has('email')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>
                  
                  <div class="row">
                     <legend class="col-form-label col-sm-2 pt-0">Role</legend>
                     <div class="col-sm-10">
                        <div>
                           <input class="form-check-input" onclick="hideorshow();" type="radio" name="role" id="gridRadios1" value="0" checked>
                           <label class="form-check-label" for="gridRadios1">
                           Client
                           </label>
                        </div>
                        <div>
                           <input class="form-check-input" onclick="hideorshow();" type="radio" name="role" id="gridRadios2" value="1">
                           <label class="form-check-label" for="gridRadios2">
                           Pro
                           </label>
                        </div>

                        <div id="reveal-if-active" style="display: none;">
                           <label class="form-check-label" for="licenseNum">License Number</label>
                           <input id="licenseNum" type="text" class="form-control" name="licenseNum">

                           <label class="form-check-label" for="insuranceNum">Insurance Number</label>
                           <input id="insuranceNum" type="text" class="form-control" name="insuranceNum">

                           <label class="form-check-label" for="liabilityNum">Liability Number</label>
                           <input id="liabilityNum" type="text" class="form-control" name="liabilityNum">
                        </div>

                     </div>
                  </div>
                  <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                     <label for="password" class="col-md-4 control-label">Password</label>
                     <div class="col-md-6">
                        <input id="password" type="password" class="form-control" name="password" required>
                        <?php if($errors->has('password')): ?>
                        <span class="help-block">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                     </div>
                  </div>
                  <div class="form-group">
                     <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>
                     <div class="col-md-6">
                        <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                     </div>
                  </div>
                  <div class="form-group">
                     <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-primary">
                        Register
                        </button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<script>
function hideorshow() {
   if (document.getElementById("gridRadios2").checked) {
 
      document.getElementById("reveal-if-active").style.display = 'block';

   } else if(document.getElementById("gridRadios1").checked) {

      document.getElementById("reveal-if-active").style.display = 'none';

   }  else {

      document.getElementById("reveal-if-active").style.display = 'none';
   }
}
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>