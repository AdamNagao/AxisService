<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="description" content="">
      <meta name="author" content="">
      <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
      <link href="css/default.css" rel="stylesheet">
      <?php echo $__env->yieldContent('head'); ?>
      <title>Axis Service</title>
   </head>
   <body>
    <div id="wrapper">
      <nav class="navbar navbar-dark bg-dark box-shadow fixed-top">
        <div class="container">
          <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
         <span class="navbar-toggler-icon"></span>
         </button>
         <a class="navbar-brand" href="/AxisService/public">Axis Service</a>
         <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
               <li class="nav-item dropdown">
                  <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                      <?php if(Auth::guest()): ?>
                        
                        <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>">Register</a></li>

                      <?php else: ?>

                        <?php if(Auth::user()->role==0): ?>
                          
                          <li><a href="/AxisService/public/home">Home</a></li>
                          <li><a href="/AxisService/public/order">Order a new job</a></li>
                          <li><a href="/AxisService/public/orders">Your Orders</a></li>
                          <li><a href="/AxisService/public/profile/<?php echo e(Auth::user()->id); ?>">Your Profile</a></li>          
                        <?php elseif(Auth::user()->role==1): ?>
                          
                          <li><a href="/AxisService/public/home">Home</a></li>
                          <li><a href="/AxisService/public/viewJobs">View Jobs</a></li>
                          <li><a href="/AxisService/public/orders">Your Jobs</a></li>
                          <li><a href="profile/<?php echo e(Auth::user()->id); ?>">Your Profile</a></li>  
                        <?php elseif(Auth::user()->role==2): ?>
                          
                          <li><a href="/AxisService/public/home">Home</a></li>
                          <li><a href="/AxisService/public/vieworders">Create an Order</a></li>
                          <li><a href="/AxisService/public/orders">View all Orders</a></li>
                          <li><a href="profile/<?php echo e(Auth::user()->id); ?>">Your Profile</a></li>  
                        <?php endif; ?>

                          <li>
                          <a href="<?php echo e(route('logout')); ?>"
                          onclick="event.preventDefault();
                          document.getElementById('logout-form').submit();">Logout</a>
                          <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                          <?php echo e(csrf_field()); ?>

                          </form>
                          </li>  

                      <?php endif; ?>
                      <li><a href="/AxisService/public/contact">Contact</a></li>
                      <li><a href="/AxisService/public/about">About</a></li>
                  </div>
               </li>
            </ul>
         </div>
       </div>
      </nav>


      <?php echo $__env->yieldContent('content'); ?>
      </div>
   </body>

      <!-- Bootstrap core JavaScript
         ================================================== -->
      <!-- Placed at the end of the document so the pages load faster -->
<!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
      <script src="https://npmcdn.com/tether@1.2.4/dist/js/tether.min.js"></script>
      <script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
      <script>
        feather.replace()
      </script>
<?php echo $__env->yieldContent('foot'); ?>