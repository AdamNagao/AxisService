<?php $__env->startSection('head'); ?>
    <link href="css/home.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
   <div class="row" style="margin-top:10%" >
      <div class="col-xs-3 col-sm-3 col-md-3"></div>
      <div class="col-xs-6 col-sm-6 col-md-6">
<h1>Leave a Review for <?php echo e($user->first); ?>,<?php echo e($user->last); ?></h1>

<form action='createorder' method="POST">
<?php echo e(csrf_field()); ?>

  <div class="form-group"> 
    <label for="description">Service Description</label>
    <input type="text" name="description">
    <br><br\>
    <label for="address">Street Address</label>
    <input type="text" name="address">
    <br><br\>
    <label for="city">City</label>
    <input type="text" name="city">
    <br><br\>
    <label for="state">State</label>
    <input type="text" name="state">
    <br><br\>
    <label for="phonenumber">Phone Number</label>
    <input type="text" name="phonenumber">
  </div>
  <input class="btn btn-primary" type="submit" value="Submit">
  </input>
</form>
      </div>
      <div class="col-xs-3 col-sm-3 col-md-3"></div>
   </div>
</div>
     
            
<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>