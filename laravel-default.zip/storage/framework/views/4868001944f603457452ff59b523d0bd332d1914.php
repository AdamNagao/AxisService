<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-6">
        <h2 class="text-md-center mb-5 mt-5">Create New Profile</h2>
        <form method="post" action="/profile" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
                <input type="text" class="form-control" name="name" placeholder="Enter your name">
            </div>
            <div class="form-group">
                <label class="custom-file form-control">
                    <input type="file" name="avatar" class="custom-file-input">
                    <span class="custom-file-control"></span>
                </label>
            </div>
            <button type="submit" class="btn btn-primary form-control">Create</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.defaultWithSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>