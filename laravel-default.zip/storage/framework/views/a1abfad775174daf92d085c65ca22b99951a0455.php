<?php $__env->startSection('content'); ?>  
<?php if(Auth::check()): ?>   
<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div class="card ">
            <div class="card-header">
               <h3 class="text-xs-center"><strong>Job summary</strong></h3>
               <?php if($order->active==0): ?>
               <p>Progress: Completed</p>
               <p>Completed by (Pro): <?php echo e($order->proId); ?></p>
               <?php else: ?>
               <p>Progress: Pending</p>
               <?php endif; ?>

               <?php 
                  $proId = Auth::user()->id; //the current pro
                  $proIdList = $order->proId; //the list of signed up pros
                  $array = explode(',', $proIdList); //break the list on commas
                  $proIsSignedUp = false;

                  foreach($array as $value) { //traverse the array to check if the pro has already signed up
                     if($value == $proId){
                        $proIsSignedUp = true;
                     }
                  }  
                  
                  if($proIsSignedUp){

                  } else {
                     echo "<div class='card-block'>";
                     echo "<form action='acceptJob/$order->id' method='POST'>";


                   ?>

                  <?php echo e(csrf_field()); ?>

                  <?php echo e(method_field('PUT')); ?>

                  
                  <?php                    
                     echo "<input class='btn btn-primary' type='submit' value='Accept Job'></input>";
                     echo "<a class ='btn btn-primary' href='$order->userId'>View Profile</a>";
                     echo "</form>";
                     echo "</div>";
                  }               
                ?>

               <br>
               <strong><?php echo e($order->first); ?>, <?php echo e($order->last); ?>:</strong><br>
               <p>Description: <?php echo e($order->description); ?></p>
               <p>Street Address: <?php echo e($order->address); ?></p>
               <p>City: <?php echo e($order->city); ?></p>
               <p>State: <?php echo e($order->state); ?></p>
               <p>Phone Number: <?php echo e($order->phonenumber); ?></p>
               <?php if($order->active == 1): ?>
                  <p>Status: Waiting for Pro's</p>
               <?php elseif($order->active ==2): ?>
                  <p>Status: Accepted by Pro(s)</p>
               <?php elseif($order->active == 3): ?>
                  <p>Status: Quoted by Pro(s)</p>
               <?php endif; ?>
            </div>
         </div>
      </div>
   </div>
</div>
<br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.defaultWithSidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>