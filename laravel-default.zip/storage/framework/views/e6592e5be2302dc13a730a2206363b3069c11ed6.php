<?php $__env->startSection('head'); ?>
    <link href="css/home.css" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



<div class="container">
   <div class="row" style="margin-top:10%" >
      <div class="col-xs-3 col-sm-3 col-md-3"></div>
      <div class="col-xs-6 col-sm-6 col-md-6">
			<h1>Your Profile</h1>
			<?php if(Auth::check()): ?>

			<p><?php echo e(Auth::user()->first); ?>,<?php echo e(Auth::user()->last); ?></p>
			<p><?php echo e(Auth::user()->address); ?>,<?php echo e(Auth::user()->city); ?>,<?php echo e(Auth::user()->state); ?></p>
			<p><?php echo e(Auth::user()->phonenumber); ?>,<?php echo e(Auth::user()->email); ?></p>
			<p> Role: <?php echo e(Auth::user()->role); ?></p>
    		   
		<?php endif; ?>     
      </div>
      <div class="col-xs-3 col-sm-3 col-md-3"></div>
   </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('foot'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>